import random
import sys
import time
import string


# waktu jeda

def tunggu(teks):
    for i in teks + "\n":
        sys.stdout.write(i)
        sys.stdout.flush()
        time.sleep(1)


def singleList():
    for i in dataNasabah:
        for j in i:
            dataNasabah2.append(j)


# Buka file

def openFile():
    f = open('nasabah.txt')
    for each_line in f:
        data = each_line.split(",")
        dataNasabah.append([data[0], data[1], int(data[2])])
    f.close()


dataNasabah = []
dataNasabah2 = []

# daftar menu
while True:
    print("\n", "*"*5, "SELAMAT DATANG DI NF BANK", "*"*5)
    print("\n" + """MENU:
[1] Buka rekening
[2] Setoran tunai
[3] Tarik tunai
[4] Transfer
[5] Lihat daftar transfer
[6] Keluar
[7] Info saldo""" + "\n")
    menu = input("Masukkan menu pilihan anda: ")

    if menu == "1":
        print("\n", "*"*3, "BUKA REKENING", "*"*3, "\n")
        nama = input("Masukkan nama: ")
        setoranAwal = int(input("Masukkan setoran awal: "))
        norek = "REK" + ''.join(random.choice(string.digits) for i in range(3))
        tunggu(".....")
        print("Pembukaan rekening dengan nomor",
              norek, "atas nama", nama, "berhasil.")
        nasabah = [norek, nama, str(setoranAwal)]
        myfile = open('nasabah.txt', 'a+')
        myfile.write('\n' + ','.join(nasabah))
        myfile.close()

    elif menu == "2":
        print("\n", "*"*3, "SETORAN TUNAI", "*"*3)
        nomorRekening = input("Masukkan nomor rekening: ")
        nominal = int(input("Masukkan nominal yang akan disetor: "))
        nomorRekening = nomorRekening.upper()
        openFile()
        singleList()
        if nomorRekening in dataNasabah2:
            for i in dataNasabah:
                if i[0] == nomorRekening:
                    # dataNasabah[0]
                    print("Setoran tunai sebesar", nominal,
                          "ke rekening", nomorRekening, "berhasil.")
                    i[2] += nominal
                    with open('nasabah.txt', 'w') as f:
                        f.write(
                            '\n'.join(map(lambda x: ','.join(map(str, x)),  dataNasabah)))
                    f.close()
                    break
        else:
            print("Nomor rekening tidak terdaftar. Setoran tunai gagal.")
        dataNasabah.clear()
        dataNasabah2.clear()

    elif menu == "3":
        print("\n", "*"*3, "TARIK TUNAI", "*"*3)
        nomorRekening = input("\nMasukkan nomor rekening: ")
        nominal = int(input("Masukkan nominal yang akan ditarik: "))
        nomorRekening = nomorRekening.upper()
        openFile()
        singleList()
        if nomorRekening in dataNasabah2:
            for i in dataNasabah:
                if i[0] == nomorRekening:
                    if nominal > i[2]:
                        print("Saldo tidak mencukupi. Tarik tunai gagal.")
                        break
                    else:
                        i[2] -= nominal
                        with open('nasabah.txt', 'w') as f:
                            f.write(
                                '\n'.join(map(lambda x: ','.join(map(str, x)),  dataNasabah)))
                        f.close()
                        print("Tarik tunai sebesar", nominal,
                              "dari rekening", nomorRekening, "berhasil.\n")
                        break
        else:
            print("Nomor rekening tidak terdaftar. Tarik tunai gagal.")
        dataNasabah.clear()
        dataNasabah2.clear()

    elif menu == "4":
        print("\n", "*"*3, "TRANSFER", "*"*3)
        norekSumber = input("\nMasukkan nomor rekening sumber: ")
        norekTujuan = input("Masukkan nomor rekening tujuan: ")
        nominal = int(input("Masukkan nominal yang akan ditransfer: "))
        norekSumber = norekSumber.upper()
        norekTujuan = norekTujuan.upper()
        openFile()
        singleList()
        if norekSumber and norekTujuan in dataNasabah2:
            for i in dataNasabah:
                if i[0] == norekSumber:
                    if nominal > i[2]:
                        print("Saldo tidak mencukupi. Transfer gagal.")
                        break
                    else:
                        i[2] -= nominal
                        for j in dataNasabah:
                            if j[0] == norekTujuan:
                                j[2] += nominal
                                with open('nasabah.txt', 'w') as f:
                                    f.write(
                                        '\n'.join(map(lambda x: ','.join(map(str, x)),  dataNasabah)))
                                noTransfer = "TRF" + \
                                    ''.join(random.choice(string.digits)
                                            for i in range(3))
                                transfer = [noTransfer, norekSumber,
                                            norekTujuan, str(nominal)]
                                print("Transfer sebesar", nominal, "dari rekening",
                                      norekSumber, "ke rekening", norekTujuan, "berhasil.")
                                f = open('transfer.txt', 'a+')
                                f.write(','.join(transfer) + '\n')
                                f.close()
                                break
        elif norekSumber not in dataNasabah2:
            print("Nomor rekening sumber tidak terdaftar. Transfer gagal.")
        else:
            print("Nomor rekening tujuan tidak terdaftar. Transfer gagal.")
        dataNasabah.clear()
        dataNasabah2.clear()

    elif menu == "5":
        dataTransfer = []
        dataTransferSingle = []
        dataTransferSumber = []
        print("\n", "*"*3, "LIHAT DATA TRANSFER", "*"*3)
        norek = input("Masukkan nomor rekening sumber transfer: ")
        norek = norek.upper()
        f = open('transfer.txt')
        for each_line in f:
            data = each_line.split(",")
            dataTransfer.append([data[0], data[1], data[2], data[3]])
            dataTransferSumber.append(data[1])
        f.close()
        for i in dataTransfer:
            for j in i:
                dataTransferSingle.append(j)
        if norek in dataTransferSumber:
            for k in range(len(dataTransfer)):
                if norek == dataTransfer[k][1]:
                    print(dataTransfer[k][0], dataTransfer[k][1],
                          dataTransfer[k][2], int(dataTransfer[k][3]))
        elif norek not in dataTransferSingle:
            print("Nomor rekening sumber tidak terdaftar.")
        else:
            print("Tidak ada data yang ditampilkan")

    elif menu == "6":
        print("Terima kasih atas kunjungan Anda...")
        break

    elif menu == "7":
        print("\n", "*"*3, "INFO SALDO", "*"*3)
        norek = input("Masukkan nomor rekening: ")
        norek = norek.upper()
        openFile()
        singleList()
        if norek in dataNasabah2:
            for i in dataNasabah:
                if i[0] == norek:
                    print("Saldo rekening anda:", i[2])
        else:
            print("Nomor rekening tidak terdaftar")
        dataNasabah.clear()
        dataNasabah2.clear()
    else:
        print("Pilihan anda salah. Ulangi.")
